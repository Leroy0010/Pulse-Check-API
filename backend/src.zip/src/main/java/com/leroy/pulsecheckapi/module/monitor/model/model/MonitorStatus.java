package com.leroy.pulsecheckapi.module.monitor.model.model;


public enum MonitorStatus {
    ACTIVE, PAUSED, DOWN
}

