package com.leroy.pulsecheckapi.module.monitor.repository;

import com.leroy.pulsecheckapi.module.monitor.model.model.Monitor;
import com.leroy.pulsecheckapi.module.monitor.model.model.MonitorStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MonitorRepository extends JpaRepository<Monitor, String> {
    // Finds all active monitors where the current time has surpassed the expected heartbeat
    List<Monitor> findByStatusAndNextExpectedHeartbeatBefore(MonitorStatus status, LocalDateTime currentTime);
}