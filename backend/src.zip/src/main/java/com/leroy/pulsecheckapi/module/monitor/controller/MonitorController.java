package com.leroy.pulsecheckapi.module.monitor.controller;

import com.leroy.pulsecheckapi.module.monitor.model.model.Monitor;
import com.leroy.pulsecheckapi.module.monitor.service.MonitorService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/monitors")
@RequiredArgsConstructor
@Tag(name = "Monitors")
public class MonitorController {

    private final MonitorService monitorService;

    // User Story 1: Registering a Monitor
    @PostMapping
    public ResponseEntity<String> registerMonitor(@RequestBody Monitor monitor) {
        monitorService.createMonitor(monitor);
        return ResponseEntity.status(HttpStatus.CREATED).body("Monitor created successfully.");
    }

    // User Story 2: The Heartbeat
    @PostMapping("/{id}/heartbeat")
    public ResponseEntity<Void> heartbeat(@PathVariable String id) {
        monitorService.processHeartbeat(id);
        return ResponseEntity.ok().build();
    }

    // Bonus Story: The Snooze Button
    @PostMapping("/{id}/pause")
    public ResponseEntity<Void> pauseMonitor(@PathVariable String id) {
        monitorService.pauseMonitor(id);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMonitor(@PathVariable String id) {
        monitorService.deleteMonitor(id);
        return ResponseEntity.noContent().build();
    }
}