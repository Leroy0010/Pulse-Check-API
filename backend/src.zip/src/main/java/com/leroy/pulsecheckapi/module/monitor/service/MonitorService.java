package com.leroy.pulsecheckapi.module.monitor.service;

import com.leroy.pulsecheckapi.module.monitor.model.model.Monitor;
import com.leroy.pulsecheckapi.module.monitor.model.model.MonitorStatus;
import com.leroy.pulsecheckapi.module.monitor.repository.MonitorRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

@Slf4j
@Service
@RequiredArgsConstructor
public class MonitorService {

    private final MonitorRepository monitorRepository;

    public Monitor createMonitor(Monitor monitor) {
        if (monitorRepository.existsById(monitor.getId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Monitor ID already exists");
        }

        monitor.setStatus(MonitorStatus.ACTIVE);
        monitor.setNextExpectedHeartbeat(LocalDateTime.now(ZoneOffset.UTC).plusSeconds(monitor.getTimeout()));
        return monitorRepository.save(monitor);
    }

    public void processHeartbeat(String id) {
        Monitor monitor = monitorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Monitor not found"));

        // Update the expected heartbeat time and ensure status is ACTIVE (un-pausing or recovering)
        monitor.setNextExpectedHeartbeat(LocalDateTime.now(ZoneOffset.UTC).plusSeconds(monitor.getTimeout()));
        monitor.setStatus(MonitorStatus.ACTIVE);

        monitorRepository.save(monitor);
    }

    public void pauseMonitor(String id) {
        Monitor monitor = monitorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Monitor not found"));

        monitor.setStatus(MonitorStatus.PAUSED);
        monitor.setNextExpectedHeartbeat(null); // Clear the timer
        monitorRepository.save(monitor);
    }

    public void deleteMonitor(String id) {
        if (!monitorRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Monitor not found");
        }
        monitorRepository.deleteById(id);
    }


}