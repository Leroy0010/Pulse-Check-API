package com.leroy.pulsecheckapi.shared.scheduler;

import com.leroy.pulsecheckapi.module.monitor.model.model.Monitor;
import com.leroy.pulsecheckapi.module.monitor.model.model.MonitorStatus;
import com.leroy.pulsecheckapi.module.monitor.repository.MonitorRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class MonitorScheduler {
    private final MonitorRepository monitorRepository;

    // --- THE WATCHDOG (Runs every 5 seconds) ---
    @Scheduled(fixedRate = 5000)
    public void checkTimers() {
        LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
        List<Monitor> expiredMonitors = monitorRepository.findByStatusAndNextExpectedHeartbeatBefore(
                MonitorStatus.ACTIVE, now
        );

        for (Monitor monitor : expiredMonitors) {
            // 1. Log the alert as requested by User Story 3
            String alertJson = String.format("{\"ALERT\": \"Device %s is down!\", \"time\": \"%s\", \"email\": \"%s\"}",
                    monitor.getId(), now, monitor.getAlertEmail());
            log.error(alertJson);

            // 2. Update status to DOWN so we don't alert multiple times
            monitor.setStatus(MonitorStatus.DOWN);
            monitorRepository.save(monitor);
        }
    }
}
