CREATE TABLE monitors
(
    id                      VARCHAR(120) PRIMARY KEY,
    timeout                 SMALLINT                              NOT NULL,
    alert_email             VARCHAR(150)                          NOT NULL,
    status                  VARCHAR(20) DEFAULT 'ACTIVE'          NOT NULL,
    next_expected_heartbeat TIMESTAMP,
    created_at              TIMESTAMP   DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP   DEFAULT CURRENT_TIMESTAMP NOT NULL
);